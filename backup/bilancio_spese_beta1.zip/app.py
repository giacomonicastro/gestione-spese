import sqlite3
from flask import Flask, render_template, request, redirect, url_for, flash
import os
from datetime import datetime, timedelta
import locale # Per i nomi dei mesi in italiano, anche se useremo un approccio più diretto

app = Flask(__name__)
app.secret_key = 'la_tua_chiave_segreta_ancora_piu_segreta_e_unica_e_cambiata!' # CAMBIALA!

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE = os.path.join(BASE_DIR, 'spese.db')
SCHEMA_FILE = os.path.join(BASE_DIR, 'schema.sql')

# Lista predefinita per le categorie di spesa
CATEGORIE_SPESA = [
    "Alimenti", "Salute", "Viaggi", "Uscite-Amici", "Uscite-Coppia", 
    "Shopping", "Benzina", "Abbonamenti", "Finanziamenti", "Casa", "Regali", "Varie"
]

# Mapping per i nomi dei mesi in italiano
MESI_ITALIANI = {
    1: "Gennaio", 2: "Febbraio", 3: "Marzo", 4: "Aprile", 5: "Maggio", 6: "Giugno",
    7: "Luglio", 8: "Agosto", 9: "Settembre", 10: "Ottobre", 11: "Novembre", 12: "Dicembre"
}

# --- Filtro Jinja Personalizzato per Formattazione Decimali ---
@app.template_filter('format_decimali_italiano')
def format_decimali_italiano(valore):
    if valore is None:
        return "0" # O un altro placeholder se preferisci
    try:
        valore_float = float(valore)
        if valore_float == int(valore_float): # È un intero o ha .00
            return str(int(valore_float))
        else:
            # Formatta con 2 decimali e sostituisce il punto con la virgola
            return "{:,.2f}".format(valore_float).replace('.', '#').replace(',', '.').replace('#', ',')
    except (ValueError, TypeError):
        return str(valore) # Restituisci il valore originale se non è un numero

# --- Funzioni Helper per il Database ---
def get_db():
    db = sqlite3.connect(DATABASE)
    db.row_factory = sqlite3.Row
    return db

def init_db():
    # ... (codice init_db invariato dalla versione precedente) ...
    print(f"Tentativo di inizializzare il database usando lo schema: {SCHEMA_FILE}")
    print(f"Il database verrà creato/usato qui: {DATABASE}")
    if not os.path.exists(SCHEMA_FILE):
        print(f"ERRORE CRITICO: Il file '{SCHEMA_FILE}' non è stato trovato.")
        return
    db_conn = None
    try:
        db_conn = get_db()
        with open(SCHEMA_FILE, mode='r') as f:
            db_conn.cursor().executescript(f.read())
        db_conn.commit()
        print("Database inizializzato con successo.")
    except sqlite3.Error as e:
        print(f"Errore SQLite durante init_db: {e}")
    except Exception as e:
        print(f"Errore generico durante init_db: {e}")
    finally:
        if db_conn:
            db_conn.close()

# --- Rotte dell'Applicazione ---
@app.route('/')
@app.route('/<int:anno>/<int:mese>')
def index(anno=None, mese=None):
    oggi = datetime.today()
    if anno is None: anno = oggi.year
    if mese is None: mese = oggi.month

    try:
        data_corrente_dt = datetime(anno, mese, 1)
    except ValueError:
        flash("Data non valida, mostro il mese corrente.", "warning")
        anno, mese = oggi.year, oggi.month
        data_corrente_dt = datetime(anno, mese, 1)
    
    # Usa il mapping per il nome del mese in italiano
    nome_mese_corrente = f"{MESI_ITALIANI.get(data_corrente_dt.month, '')} {data_corrente_dt.year}"

    mese_precedente_dt = data_corrente_dt - timedelta(days=1)
    anno_prec, mese_prec = mese_precedente_dt.year, mese_precedente_dt.month

    if data_corrente_dt.month == 12:
        primo_giorno_mese_successivo_dt = datetime(data_corrente_dt.year + 1, 1, 1)
    else:
        primo_giorno_mese_successivo_dt = datetime(data_corrente_dt.year, data_corrente_dt.month + 1, 1)
    anno_succ, mese_succ = primo_giorno_mese_successivo_dt.year, primo_giorno_mese_successivo_dt.month
    
    entrate_giacomo, entrate_erica = 0.0, 0.0
    spese_giacomo, spese_erica = 0.0, 0.0
    
    spese_display_list = []
    entrate_display_list = []
    
    db = None
    try:
        db = get_db()
        anno_mese_str = f"{anno:04d}-{mese:02d}"
        
        cursore_entrate_persona = db.execute('SELECT ricevuto_da, SUM(importo) as totale FROM entrate WHERE strftime("%Y-%m", data) = ? GROUP BY ricevuto_da', (anno_mese_str,))
        for row in cursore_entrate_persona:
            if row['ricevuto_da'] == 'Giacomo': entrate_giacomo = row['totale'] or 0.0
            elif row['ricevuto_da'] == 'Erica': entrate_erica = row['totale'] or 0.0
        
        cursore_spese_persona = db.execute('SELECT pagato_da, SUM(importo) as totale FROM spese WHERE strftime("%Y-%m", data) = ? GROUP BY pagato_da', (anno_mese_str,))
        for row in cursore_spese_persona:
            if row['pagato_da'] == 'Giacomo': spese_giacomo = row['totale'] or 0.0
            elif row['pagato_da'] == 'Erica': spese_erica = row['totale'] or 0.0

        raw_entrate_per_persona_tipo = db.execute('SELECT tipo_entrata, ricevuto_da, SUM(importo) as totale_parziale FROM entrate WHERE strftime("%Y-%m", data) = ? GROUP BY tipo_entrata, ricevuto_da ORDER BY LOWER(tipo_entrata), ricevuto_da', (anno_mese_str,)).fetchall()
        entrate_pivot = {}
        for row in raw_entrate_per_persona_tipo:
            tipo, ricevente, totale = row['tipo_entrata'], row['ricevuto_da'], row['totale_parziale'] or 0.0
            if tipo not in entrate_pivot: entrate_pivot[tipo] = {'Giacomo': 0.0, 'Erica': 0.0, 'Totale': 0.0}
            if ricevente == 'Giacomo': entrate_pivot[tipo]['Giacomo'] += totale
            elif ricevente == 'Erica': entrate_pivot[tipo]['Erica'] += totale
            entrate_pivot[tipo]['Totale'] += totale
        for tipo, data_pivot in entrate_pivot.items():
            entrate_display_list.append({'tipo_entrata': tipo, 'importo_giacomo': data_pivot['Giacomo'], 'importo_erica': data_pivot['Erica'], 'importo_totale': data_pivot['Totale']})
        entrate_display_list.sort(key=lambda x: x['tipo_entrata'].lower())

        raw_spese_per_persona_categoria = db.execute('SELECT categoria, pagato_da, SUM(importo) as totale_parziale FROM spese WHERE strftime("%Y-%m", data) = ? GROUP BY categoria, pagato_da ORDER BY LOWER(categoria), pagato_da', (anno_mese_str,)).fetchall()
        spese_pivot = {}
        for row in raw_spese_per_persona_categoria:
            cat, pagante, totale = row['categoria'], row['pagato_da'], row['totale_parziale'] or 0.0
            if cat not in spese_pivot: spese_pivot[cat] = {'Giacomo': 0.0, 'Erica': 0.0, 'Totale': 0.0}
            if pagante == 'Giacomo': spese_pivot[cat]['Giacomo'] += totale
            elif pagante == 'Erica': spese_pivot[cat]['Erica'] += totale
            spese_pivot[cat]['Totale'] += totale
        for cat, data_pivot in spese_pivot.items():
            spese_display_list.append({'categoria': cat, 'importo_giacomo': data_pivot['Giacomo'], 'importo_erica': data_pivot['Erica'], 'importo_totale_categoria': data_pivot['Totale']})
        spese_display_list.sort(key=lambda x: x['categoria'].lower())
            
    except sqlite3.Error as e:
        flash(f"Errore nel caricare i dati finanziari del mese: {e}", "danger")
        print(f"Errore SQLite nel caricare dati per {anno_mese_str}: {e}")
    finally:
        if db: db.close()

    risparmio_giacomo = entrate_giacomo - spese_giacomo
    risparmio_erica = entrate_erica - spese_erica
    
    totale_entrate_mese_complessivo = entrate_giacomo + entrate_erica
    totale_spese_mese_complessivo = spese_giacomo + spese_erica
    risparmio_mese_complessivo = totale_entrate_mese_complessivo - totale_spese_mese_complessivo

    return render_template('index.html', 
                           titolo="Bilancio Mensile", nome_mese_corrente=nome_mese_corrente,
                           anno_prec=anno_prec, mese_prec=mese_prec, anno_succ=anno_succ, mese_succ=mese_succ,
                           current_anno=anno, current_mese=mese,
                           entrate_giacomo=entrate_giacomo, entrate_erica=entrate_erica,
                           spese_giacomo=spese_giacomo, spese_erica=spese_erica,
                           risparmio_giacomo=risparmio_giacomo, risparmio_erica=risparmio_erica,
                           totale_entrate_mese=totale_entrate_mese_complessivo,
                           totale_spese_mese=totale_spese_mese_complessivo,
                           risparmio_mese=risparmio_mese_complessivo,
                           entrate_mese_dettagliate=entrate_display_list, 
                           spese_mese_dettagliate=spese_display_list,
                           categorie_spesa_disponibili=CATEGORIE_SPESA, # Passa le categorie al template
                           datetime=datetime)

@app.route('/dettagli_spese/<int:anno>/<int:mese>/<path:nome_categoria>')
def dettagli_categoria_mese(anno, mese, nome_categoria):
    # ... (Codice Invariato, ma il nome del mese sarà gestito dal template) ...
    transazioni_dettaglio = []
    nome_mese_categoria_display = ""
    totale_categoria = 0.0
    try:
        data_corrente_dt = datetime(anno, mese, 1)
        nome_mese_categoria_display = f"{MESI_ITALIANI.get(data_corrente_dt.month, '')} {data_corrente_dt.year}"
    except ValueError:
        flash("Data non valida per i dettagli.", "danger")
        return redirect(url_for('index'))
    db = None
    try:
        db = get_db()
        anno_mese_str = f"{anno:04d}-{mese:02d}"
        cursore = db.execute('''
            SELECT id, data, descrizione, importo, pagato_da 
            FROM spese
            WHERE strftime('%Y-%m', data) = ? AND categoria = ?
            ORDER BY data DESC, id DESC
        ''', (anno_mese_str, nome_categoria))
        transazioni_dettaglio = cursore.fetchall()
        for transazione in transazioni_dettaglio:
            totale_categoria += transazione['importo']
    except sqlite3.Error as e:
        flash(f"Errore nel caricare i dettagli per '{nome_categoria}': {e}", "danger")
        print(f"Errore SQLite nel caricare dettagli per {nome_categoria} in {anno_mese_str}: {e}")
        return redirect(url_for('index', anno=anno, mese=mese))
    finally:
        if db: db.close()
    return render_template('dettagli_categoria_mese.html',
                           titolo_pagina=f"Dettaglio Spese: {nome_categoria}",
                           nome_categoria=nome_categoria,
                           nome_mese=nome_mese_categoria_display,
                           transazioni=transazioni_dettaglio,
                           totale_categoria_mese=totale_categoria,
                           current_anno=anno, current_mese=mese, datetime=datetime)

@app.route('/aggiungi_transazione', methods=['POST'])
def aggiungi_transazione():
    # ... (Codice Invariato) ...
    if request.method == 'POST':
        tipo_transazione = request.form.get('tipo_transazione')
        data = request.form.get('data')
        importo_str = request.form.get('importo')
        if not all([tipo_transazione, data, importo_str]):
            flash("Errore: Tipo transazione, data e importo sono obbligatori!", "danger")
            return redirect(url_for('index'))
        try:
            importo = float(importo_str)
            if importo <= 0:
                flash("Errore: l'importo deve essere un numero positivo.", "danger")
                return redirect(url_for('index'))
            data_transazione_dt = datetime.strptime(data, '%Y-%m-%d')
        except ValueError:
            flash("Errore: l'importo o la data inseriti non sono validi.", "danger")
            return redirect(url_for('index'))
        db = None
        try:
            db = get_db()
            if tipo_transazione == 'spesa':
                # Categoria ora viene da un <select>
                categoria = request.form.get('categoria_spesa_select') # Nome aggiornato del campo select
                descrizione = request.form.get('descrizione_spesa') 
                pagato_da = request.form.get('pagato_da')
                if not all([categoria, pagato_da]): # Descrizione può essere opzionale se la categoria è chiara
                     flash("Errore: Categoria e 'pagato da' sono obbligatori per una spesa!", "danger")
                     return redirect(url_for('index', anno=data_transazione_dt.year, mese=data_transazione_dt.month))
                db.execute('INSERT INTO spese (data, descrizione, categoria, importo, pagato_da) VALUES (?, ?, ?, ?, ?)',
                           (data, descrizione if descrizione else "", categoria, importo, pagato_da)) # Descrizione può essere vuota
                flash(f"Spesa '{categoria}{' - ' + descrizione if descrizione else ''}' aggiunta con successo!", "success")
            elif tipo_transazione == 'entrata':
                tipo_entrata_val = request.form.get('tipo_entrata_val')
                descrizione_entrata = request.form.get('descrizione_entrata') 
                ricevuto_da = request.form.get('ricevuto_da')
                if not all([tipo_entrata_val, ricevuto_da]):
                     flash("Errore: Tipo entrata e 'ricevuto da' sono obbligatori per un'entrata!", "danger")
                     return redirect(url_for('index', anno=data_transazione_dt.year, mese=data_transazione_dt.month))
                db.execute('INSERT INTO entrate (data, tipo_entrata, descrizione, importo, ricevuto_da) VALUES (?, ?, ?, ?, ?)',
                           (data, tipo_entrata_val, descrizione_entrata if descrizione_entrata else "", importo, ricevuto_da))
                flash(f"Entrata '{tipo_entrata_val}{' - ' + descrizione_entrata if descrizione_entrata else ''}' aggiunta con successo!", "success")
            else:
                flash("Errore: Tipo di transazione non valido.", "danger")
                return redirect(url_for('index', anno=data_transazione_dt.year, mese=data_transazione_dt.month))
            db.commit()
        except sqlite3.Error as e:
            flash(f"Errore durante l'aggiunta della transazione al database: {e}", "danger")
            print(f"Errore SQLite: {e}")
        except Exception as e_gen:
            flash(f"Errore generico durante l'aggiunta: {e_gen}", "danger")
            print(f"Errore generico: {e_gen}")
        finally:
            if db: db.close()
        return redirect(url_for('index', anno=data_transazione_dt.year, mese=data_transazione_dt.month))
    return redirect(url_for('index'))

@app.route('/modifica_spesa/<int:spesa_id>', methods=['GET'])
def modifica_spesa_form(spesa_id):
    # ... (Codice Invariato, ma ora passa anche CATEGORIE_SPESA) ...
    spesa_da_modificare = None; db = None
    try:
        db = get_db()
        cursore = db.execute('SELECT id, data, descrizione, categoria, importo, pagato_da FROM spese WHERE id = ?', (spesa_id,))
        spesa_da_modificare = cursore.fetchone()
    except sqlite3.Error as e:
        flash("Errore nel caricare la spesa da modificare.", "danger"); print(f"Errore SQLite: {e}")
        return redirect(url_for('index')) 
    finally:
        if db: db.close()
    if spesa_da_modificare is None:
        flash(f"Spesa con ID {spesa_id} non trovata.", "danger")
        return redirect(url_for('index'))
    return render_template('modifica_spesa.html', 
                           spesa=spesa_da_modificare, 
                           titolo_pagina="Modifica Spesa",
                           categorie_spesa_disponibili=CATEGORIE_SPESA, # Passa le categorie
                           datetime=datetime)

@app.route('/modifica_spesa/<int:spesa_id>/salva', methods=['POST'])
def processa_modifica_spesa(spesa_id):
    # ... (Codice Invariato, ma categoria ora viene da un select) ...
    anno_redirect, mese_redirect = datetime.today().year, datetime.today().month
    db_temp = None
    try: 
        db_temp = get_db()
        cursore_data_orig = db_temp.execute('SELECT data FROM spese WHERE id = ?', (spesa_id,))
        data_record_orig = cursore_data_orig.fetchone()
        if data_record_orig:
            dt_orig = datetime.strptime(data_record_orig['data'], '%Y-%m-%d')
            anno_redirect, mese_redirect = dt_orig.year, dt_orig.month
    except Exception as e: print(f"Errore recupero data originale per redirect spesa ID {spesa_id}: {e}")
    finally:
        if db_temp: db_temp.close()
    if request.method == 'POST':
        data_nuova = request.form.get('data')
        categoria = request.form.get('categoria_spesa_select') # Nome aggiornato del campo select
        descrizione = request.form.get('descrizione_spesa')
        importo_str = request.form.get('importo')
        pagato_da = request.form.get('pagato_da')
        if not all([data_nuova, categoria, importo_str, pagato_da]): # Descrizione può essere opzionale
            flash("Errore: Data, Categoria, Importo e Pagato Da sono obbligatori!", "danger")
            return redirect(url_for('modifica_spesa_form', spesa_id=spesa_id))
        try:
            importo = float(importo_str)
            if importo <=0: raise ValueError("Importo non positivo")
            dt_nuova = datetime.strptime(data_nuova, '%Y-%m-%d')
            anno_redirect, mese_redirect = dt_nuova.year, dt_nuova.month
        except ValueError:
            flash("Errore: importo o data non validi.", "danger")
            return redirect(url_for('modifica_spesa_form', spesa_id=spesa_id))
        db = None
        try:
            db = get_db()
            db.execute('UPDATE spese SET data = ?, descrizione = ?, categoria = ?, importo = ?, pagato_da = ? WHERE id = ?',
                       (data_nuova, descrizione if descrizione else "", categoria, importo, pagato_da, spesa_id))
            db.commit()
            flash(f"Spesa '{categoria}{' - ' + descrizione if descrizione else ''}' aggiornata!", "success")
        except sqlite3.Error as e: flash("Errore aggiornamento spesa.", "danger"); print(f"Errore SQLite: {e}")
        finally:
            if db: db.close()
        return redirect(url_for('index', anno=anno_redirect, mese=mese_redirect))
    return redirect(url_for('index', anno=anno_redirect, mese=mese_redirect))

@app.route('/elimina_spesa/<int:spesa_id>', methods=['POST'])
def elimina_spesa(spesa_id):
    # ... (Codice Invariato) ...
    anno_redirect, mese_redirect = datetime.today().year, datetime.today().month
    db = None
    try:
        db = get_db()
        cursore_info = db.execute('SELECT data, descrizione, categoria FROM spese WHERE id = ?', (spesa_id,)) # Aggiunto categoria
        spesa_info = cursore_info.fetchone()
        if spesa_info:
            dt_spesa = datetime.strptime(spesa_info['data'], '%Y-%m-%d')
            anno_redirect, mese_redirect = dt_spesa.year, dt_spesa.month
            desc_spesa_eliminata = f"{spesa_info['categoria']}{' - ' + spesa_info['descrizione'] if spesa_info['descrizione'] else ''}"
        else: 
            flash(f"Spesa ID {spesa_id} non trovata.", "warning"); return redirect(url_for('index'))
        db.execute('DELETE FROM spese WHERE id = ?', (spesa_id,))
        db.commit()
        flash(f"Spesa '{desc_spesa_eliminata}' eliminata!", "success")
    except sqlite3.Error as e: flash("Errore eliminazione spesa.", "danger"); print(f"Errore SQLite: {e}")
    finally:
        if db: db.close()
    return redirect(url_for('index', anno=anno_redirect, mese=mese_redirect))

# --- Rotte CRUD ENTRATE (invariate dalla versione precedente) ---
@app.route('/dettagli_entrate/<int:anno>/<int:mese>/<path:nome_tipo_entrata>')
def dettagli_tipo_entrata_mese(anno, mese, nome_tipo_entrata):
    # ... (Codice Invariato, ma il nome del mese sarà gestito dal template) ...
    transazioni_dettaglio = []
    nome_mese_tipo_entrata_display = ""
    totale_tipo_entrata = 0.0
    try:
        data_corrente_dt = datetime(anno, mese, 1)
        nome_mese_tipo_entrata_display = f"{MESI_ITALIANI.get(data_corrente_dt.month, '')} {data_corrente_dt.year}"
    except ValueError:
        flash("Data non valida per i dettagli delle entrate.", "danger")
        return redirect(url_for('index'))
    db = None
    try:
        db = get_db()
        anno_mese_str = f"{anno:04d}-{mese:02d}"
        cursore = db.execute('''
            SELECT id, data, tipo_entrata, descrizione, importo, ricevuto_da 
            FROM entrate
            WHERE strftime('%Y-%m', data) = ? AND tipo_entrata = ?
            ORDER BY data DESC, id DESC
        ''', (anno_mese_str, nome_tipo_entrata))
        transazioni_dettaglio = cursore.fetchall()
        for transazione in transazioni_dettaglio:
            totale_tipo_entrata += transazione['importo']
    except sqlite3.Error as e:
        flash(f"Errore nel caricare i dettagli per il tipo entrata '{nome_tipo_entrata}': {e}", "danger")
        return redirect(url_for('index', anno=anno, mese=mese))
    finally:
        if db: db.close()
    return render_template('dettagli_tipo_entrata_mese.html',
                           titolo_pagina=f"Dettaglio Entrate: {nome_tipo_entrata}",
                           nome_tipo_entrata=nome_tipo_entrata,
                           nome_mese=nome_mese_tipo_entrata_display,
                           transazioni=transazioni_dettaglio,
                           totale_tipo_entrata_mese=totale_tipo_entrata,
                           current_anno=anno, current_mese=mese, datetime=datetime)

@app.route('/modifica_entrata/<int:entrata_id>', methods=['GET'])
def modifica_entrata_form(entrata_id):
    # ... (Codice Invariato) ...
    entrata_da_modificare = None; db = None
    try:
        db = get_db()
        cursore = db.execute('SELECT id, data, tipo_entrata, descrizione, importo, ricevuto_da FROM entrate WHERE id = ?', (entrata_id,))
        entrata_da_modificare = cursore.fetchone()
    except sqlite3.Error as e:
        flash("Errore nel caricare l'entrata da modificare.", "danger"); print(f"Errore SQLite: {e}")
        return redirect(url_for('index'))
    finally:
        if db: db.close()
    if entrata_da_modificare is None:
        flash(f"Entrata con ID {entrata_id} non trovata.", "danger")
        return redirect(url_for('index'))
    tipi_entrata_disponibili = ["Stipendio", "Bonus", "Regalo", "Vendita", "Extra", "Altro"]
    return render_template('modifica_entrata.html', 
                           entrata=entrata_da_modificare, 
                           tipi_entrata=tipi_entrata_disponibili,
                           titolo_pagina="Modifica Entrata", datetime=datetime)

@app.route('/modifica_entrata/<int:entrata_id>/salva', methods=['POST'])
def processa_modifica_entrata(entrata_id):
    # ... (Codice Invariato) ...
    anno_redirect, mese_redirect = datetime.today().year, datetime.today().month
    db_temp = None
    try: 
        db_temp = get_db()
        cursore_data_orig = db_temp.execute('SELECT data FROM entrate WHERE id = ?', (entrata_id,))
        data_record_orig = cursore_data_orig.fetchone()
        if data_record_orig:
            dt_orig = datetime.strptime(data_record_orig['data'], '%Y-%m-%d')
            anno_redirect, mese_redirect = dt_orig.year, dt_orig.month
    except Exception as e: print(f"Errore recupero data originale per redirect entrata ID {entrata_id}: {e}")
    finally:
        if db_temp: db_temp.close()
    if request.method == 'POST':
        data_nuova = request.form.get('data')
        tipo_entrata = request.form.get('tipo_entrata_val')
        descrizione = request.form.get('descrizione_entrata')
        importo_str = request.form.get('importo')
        ricevuto_da = request.form.get('ricevuto_da')
        if not all([data_nuova, tipo_entrata, importo_str, ricevuto_da]):
            flash("Errore: Data, Tipo, Importo e Ricevuto Da sono obbligatori!", "danger")
            return redirect(url_for('modifica_entrata_form', entrata_id=entrata_id))
        try:
            importo = float(importo_str)
            if importo <= 0: raise ValueError("Importo non positivo")
            dt_nuova = datetime.strptime(data_nuova, '%Y-%m-%d')
            anno_redirect, mese_redirect = dt_nuova.year, dt_nuova.month
        except ValueError:
            flash("Errore: Importo o Data non validi.", "danger")
            return redirect(url_for('modifica_entrata_form', entrata_id=entrata_id))
        db = None
        try:
            db = get_db()
            db.execute('UPDATE entrate SET data = ?, tipo_entrata = ?, descrizione = ?, importo = ?, ricevuto_da = ? WHERE id = ?',
                       (data_nuova, tipo_entrata, descrizione if descrizione else "", importo, ricevuto_da, entrata_id))
            db.commit()
            flash(f"Entrata '{tipo_entrata}{' - ' + descrizione if descrizione else ''}' aggiornata!", "success")
        except sqlite3.Error as e:
            flash("Errore aggiornamento entrata.", "danger"); print(f"Errore SQLite: {e}")
        finally:
            if db: db.close()
        return redirect(url_for('index', anno=anno_redirect, mese=mese_redirect))
    return redirect(url_for('index', anno=anno_redirect, mese=mese_redirect))

@app.route('/elimina_entrata/<int:entrata_id>', methods=['POST'])
def elimina_entrata(entrata_id):
    # ... (Codice Invariato) ...
    anno_redirect, mese_redirect = datetime.today().year, datetime.today().month
    db = None
    try:
        db = get_db()
        cursore_info = db.execute('SELECT data, tipo_entrata, descrizione FROM entrate WHERE id = ?', (entrata_id,))
        entrata_info = cursore_info.fetchone()
        if entrata_info:
            dt_entrata = datetime.strptime(entrata_info['data'], '%Y-%m-%d')
            anno_redirect, mese_redirect = dt_entrata.year, dt_entrata.month
            desc_entrata_eliminata = f"{entrata_info['tipo_entrata']}{' - ' + entrata_info['descrizione'] if entrata_info['descrizione'] else ''}"
        else:
            flash(f"Entrata ID {entrata_id} non trovata.", "warning"); return redirect(url_for('index'))
        db.execute('DELETE FROM entrate WHERE id = ?', (entrata_id,))
        db.commit()
        flash(f"Entrata '{desc_entrata_eliminata}' eliminata!", "success")
    except sqlite3.Error as e:
        flash("Errore eliminazione entrata.", "danger"); print(f"Errore SQLite: {e}")
    finally:
        if db: db.close()
    return redirect(url_for('index', anno=anno_redirect, mese=mese_redirect))

# --- Blocco Main ---
if __name__ == '__main__':
    print("Avvio applicazione...")
    # init_db() 
    app.run(debug=True)